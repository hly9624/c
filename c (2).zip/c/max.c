#include <stdio.h>

int main()
{
  int a[8] = {3,1,8,9,3,2,4,6};
  int max = 0;

  for (int i = 1; i < 8; i++) {
    if(a[max] < a[i])
    {
      max = i;
    }
  }

  printf("max is a[%d] = %d\n",max,a[max]);

  return 0;
}
