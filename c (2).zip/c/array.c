#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a[5] = {1,2,3,4,5};

  char b[5];

  a[3] = 100;
  //printf("%ld\n",sizeof(a) );

//  printf("%p\n",a);

  printf("%d\n",a[0]);
  printf("%d\n",a[1]);
  printf("%d\n",a[2]);
  printf("%d\n",a[3]);
  printf("%d\n",a[4]);

  for(int i = 0;i < 5;i++)
  {
    printf("%d\n",a[i] );
  }


  return 0;
}
