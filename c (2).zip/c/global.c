#include <stdio.h>

int a = 1;

void fun(){
  a = 2;
}

int main()
{
  int a = 100;
  fun();
  printf("a = %d\n",a);

  return 0;
}
