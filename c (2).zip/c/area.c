#include <stdio.h>
#include <math.h>

int main()
{
    int a = 3,b = 3,c = 3;

    if(a + b > c)
    {
      printf("errot\n");
      return -1;
    }

    float s,area;

    s = (a + b + c) / 2.0;

    area = sqrt(s * (s - a) * (s - b) * (s - c));

    printf("area = %.2f\n",area);

    return 0;
}
