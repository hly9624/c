#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[]) {

  char str1[] = "aello";
  char str2[] = "hello";

  printf("%d\n",strcmp(str1,str2));

/*
  int len;

  len = strlen(str);

  printf("len = %d\n",len);
*/
  return 0;
}
