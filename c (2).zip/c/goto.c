#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a;
  loop:
  scanf("%d",&a);

  if(a > 10)
  {
  ao loop;
  }

  printf("a = %d\n",a);

  return 0;
}
