#include <stdio.h>

int main(int argc, const char *argv[])
{
    int a,b;
    float c;

    printf("input : ");

    scanf("%d%d%f",&a,&b,&c);
    printf("c = %f,b = %d,a = %d\n",c,b,a);

    // scanf("%d,%3d,%f",&a,&b,&c);

    // printf("a = %d,b = %d,c = %f\n",a,b,c);
    return 0;
}
