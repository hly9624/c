#include <stdio.h>

int main(int argc, char const *argv[]) {
  // char a,b;
  // int c;
  //
  // scanf("%c",&a);
  // scanf("%d",&c);
  // scanf("%c",&b);
  //
  // printf("%c %c %d\n",a,b,c);
  int cmd;
  char clean[128] = {0};

  while(1)
  {
    if (scanf("%d", &cmd) != 1)
		{
			puts("input error !");
			fgets(clean, 128, stdin);//清空缓冲区
      printf("%s\n",clean);
			continue;
		}

    printf("cmd = %d\n",cmd);
  }


  return 0;
}
