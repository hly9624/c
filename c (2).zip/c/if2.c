#include <stdio.h>

int main(int argc, char const *argv[]) {
  int score;

  printf("Input the score : ");
  scanf("%d",&score);

  if(score < 0 || score > 100)
  {
    printf("Sorry,your score error!\n");
    return -1;
  }

  if(score >= 90)
  {
    printf("level : A\n");
  }
  else if(score >= 80)
  {
      printf("level : B\n");
  }
  else if(score >= 70)
  {
      printf("level : C\n");
  }
  else if(score >= 60)
  {
      printf("level : D\n");
  }
  else{
      printf("Sorry, lose hahahah\n");
  }

  return 0;
}
