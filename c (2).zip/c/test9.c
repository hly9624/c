#include <stdio.h>

int main(){

  int i,j,k;

  for(i = 0;i < 4;i++)
  {
    j = k = 0;
    while(j < 3 - i)
    {
      printf(" ");
      j++;
    }
    while(k <= 2 * i)
    {
      printf("*");
      k++;
    }
    printf("\n");
  }

    for(i = 4;i < 7;i++)
    {
      j = k = 0;
      while(j < i - 3)
      {
        printf(" ");
        j++;
      }
      while(k < (7 - i) * 2 - 1)
      {
        printf("*");
        k++;
      }
      printf("\n");
    }

  return 0;
}
