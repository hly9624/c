#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a[7] = {18,2,1,5,6,7,10};
  int i,j,k,tmp;

  for(i = 0;i < 7 - 1;i++)
  {
    k = i;
    for(j = k + 1;j < 7;j++)
    {
      if(a[k] > a[j])
      {
          k = j;
      }
    }
    if(i != k)
    {
      tmp = a[k];
      a[k] = a[i];
      a[i] = tmp;
    }
  }
  for(i = 0;i < 7;i++)
  {
    printf("%d ",a[i]);
  }
  printf("\n");
  return 0;
}
