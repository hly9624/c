#include <stdio.h>

int main(int argc, char const *argv[]) {
  int a[2][3] = {1,2,3,4,5,6};

  int (*p)[4] = a;

  printf("%d\n",*(*(p + 1) + 1));

  return 0;
}
