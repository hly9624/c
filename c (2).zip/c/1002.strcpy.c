#include <stdio.h>
#include <string.h>

int main(int argc, const char *argv[])
{
	char dest[128];
	char src[128] = "This is a test";

	/* 字符串的拷贝函数 */
	strcpy(dest , src);

	printf("%s\n", dest);

	return 0;
}
