#include <stdio.h>

char *mystrcpy(char *dest, const char *src)
{
  char *p = dest;
  while(*src != '\0')
  {
    *p = *src;
    p++;
    src++;
  }
  *p = '\0';

  return dest;
}

int main(int argc, const char *argv[])
{
	char dest[128] = "hello world nihao China hahhahahahah";
	char src[128] = "This is a test";

	/* 字符串的拷贝函数 */
  mystrcpy(dest,src);

	printf("%s\n", dest);

	return 0;
}
