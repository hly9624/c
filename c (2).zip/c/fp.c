#include <stdio.h>


int fun1(int (*a)(int,int),int b)
{
  return a(2,3) + b;
}

int fun2(int a,int b)
{
  return a - b;
}

// int fun3(int a,int b)
// {
//   return a * b;
// }

int main(int argc, char const *argv[]) {

  printf("%d\n",fun1(fun2,10));
  //
  // int (*p[3])(int,int) = {fun1,fun2,fun3};
  //
  // // printf("%p\n",fun);
  //
  // for(int i = 0;i < 3;i++)
  //   printf("%d\n",p[i](3,2));


  return 0;
}
