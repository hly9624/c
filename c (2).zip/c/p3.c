#include <stdio.h>

int main(int argc, char const *argv[]) {

//函数指针
  int (*p)(int,int);

//函数指针数组
  int (*p[3])(int,int);

  return 0;
}
