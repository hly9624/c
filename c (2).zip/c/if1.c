#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a;

  scanf("%d",&a);

  if(a < 20)
  {
      if (a > 0) {
        printf("0 < a < 20\n");
      }
  }
  else if(a < 30)
  {
    printf("20 <= a < 30\n");
  }
  else{
      if (a < 40) {
        printf("30 <= a < 40\n");
      } else {
        printf("a >= 40\n");
      }
  }

  return 0;
}
