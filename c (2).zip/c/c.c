#include <stdio.h>
#include "c1.h"

#define N 1

int b = 1;

int main()
{

  int a = 1;

  #ifndef N
  a = 100;
  #endif
  // union UN u;
  //
  // u.a = '$';
  // u.b = 97;
  // int a = 1;
  //
  // #if N
  // a = 10;
  // #else
  // a = 100;
  // #endif

  printf("%d\n",a);

  return 0;
}
