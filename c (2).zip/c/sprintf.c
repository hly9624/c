#include <stdio.h>

int main(int argc, char const *argv[]) {

  char str[128] = {0};
  sprintf(str,"select * from usr where id = %d",1);

  printf("%s\n",str);

  return 0;
}
