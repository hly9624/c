#include <stdio.h>

int main(int argc, char const *argv[]) {
  int i = 1,sum = 0;


  while (i <= 100) {
    sum = sum + 1;
    i++;
  }

  printf("%d\n",sum );

  return 0;
}
