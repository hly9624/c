#include <stdio.h>

// typedef struct Student{
//   int id;
//   char name[64];
//   int age;
//   float salary;
// }Stu;
//
//
// typedef struct Student  Stu;

typedef struct Student{
   int id;
   char name[64];
   int age;
   float salary;
}Stu,*S;

int main(int argc, char const *argv[]) {
  Stu a = {1,"baobao",23,8000};
  S p;

  p = &a;

  printf("%d\n",(*p).id);
  printf("%s\n",p->name);

  return 0;
}
