#include <stdio.h>

int main()
{
  int sum = 1,i = 0;

  while(i < 9)
  {
    sum = (sum + 1) * 2;
    printf("%d\n",sum );
    i++;
  }

  return 0;
}
