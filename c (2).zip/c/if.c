#include <stdio.h>

int main(int argc, const char *argv[])
{
    int a = 2,b = 1;

    if(a < b)
    {
        printf("a < b\n");
    }
    else
    {
        printf("a >= b\n");
    }
    

    return 0;
}
