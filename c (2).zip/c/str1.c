#include <stdio.h>

int main(int argc, char const *argv[]) {

  char a[12] = "hello world";

  a[0] = 'H';

  char *p;

  //printf("*p = %c\n",*(p + 1));
  //*p = 'N';
  p = a;

  printf("%s\n",a);
  printf("%s\n",p);

  return 0;
}
