#include <stdio.h>

int main()
{
  char a[5] = {'h','e','l','l','o'};

  char b[12] = "hello world";




  printf("%s\n",b);

  return 0;
}
