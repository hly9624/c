#include <stdio.h>

int main(int argc, char const *argv[]) {
  int sum = 0;

  for(int i = 1;i <= 10;i++)
  {
    int cheng = 1;
    for(int j = i;j > 0;j--)
    {
      cheng *= j;
    }
    sum += cheng;
  }

  printf("%d\n", sum);

  return 0;
}
