#include <stdio.h>

int main(int argc, char const *argv[]) {
  int a, num = 0;
  scanf("%d",&a);
  if(a == 0)
  {
    printf("1\n");
  }
  else{
  while(a)
  {
    num++;
    a /= 10;
  }
  printf("%d\n",num);
}
  return 0;
}
