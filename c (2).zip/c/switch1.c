#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a  = 1;
  int b = 10;

  switch (a) {
    case 1:
      printf("is one\n");
    case 2:
      printf("is two\n");
      break;
    case 3:
      printf("is three\n");

  }

  return 0;
}
