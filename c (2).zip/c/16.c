#include <stdio.h>

int main(int argc, char const *argv[]) {
  int N;
  scanf("%d",&N);

  printf("%#x\n",1 << N);

  return 0;
}
