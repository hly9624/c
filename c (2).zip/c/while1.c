#include <stdio.h>

int main(int argc, char const *argv[]) {
  char key;
  while (1) {

    scanf("%c",&key);
    getchar();
    if(key == 'e')
    {
      printf("我不想要'e'\n");
      continue;
    }
    printf("key = %c\n",key);
  }
  return 0;
}
