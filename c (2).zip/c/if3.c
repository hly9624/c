#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a = 1,b = 2;

  printf("%d\n",a++ || b++ );

  printf("a = %d,b = %d\n",a,b);

  return 0;
}
