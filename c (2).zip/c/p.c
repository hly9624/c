#include <stdio.h>

int main(int argc, char const *argv[]) {

  int a = 1 ,b = 2;
  int * p = &a,*q;


  q = &b;

  *p = 10;

  printf("a = %d,b = %d\n",*(&a),b);

  return 0;
}
