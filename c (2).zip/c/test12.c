#include <stdio.h>

int main(int argc, const char *argv[])
{
    unsigned long long int sum = 0;
    long int i;    

    for(i = 1;i < 9999999999;i++)
    {
        sum += i;
    }
//    sum = (1 + 999999999) * (9999999999 / 2);
    
    printf("sum = %Lu\n",sum);

    return 0;
}
