#include <stdio.h>


int main(int argc, const char *argv[])
{
    int a,b,c;
    int tmp;

    scanf("%d%d%d",&a,&b,&c);
    printf("a = %d,b = %d,c = %d\n",a,b,c);

    if(a > b)
    {
        tmp = a;
        a = b;
        b = tmp;
    }

    if(a > c)
    {
        tmp = a;
        a = c;
        c = tmp;
    }

    if(b > c)
    {
        tmp = b;
        b = c;
        c = tmp;
    }

    printf("a = %d,b = %d,c = %d\n",a,b,c);
    return 0;
}
