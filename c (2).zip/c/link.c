#include <stdio.h>
#include <stdlib.h>

// typedef struct stu{
//   int id;
//   char name[64];
//   int age;
// }datatype;

typedef int datatype;

typedef struct node{
  datatype data;
  struct node *next;
}linknode,*linklist;

linklist link_create()
{
  linklist p = NULL;
  if((p = malloc(sizeof(linknode))) == NULL)
  {
    printf("malloc error!\n");
    return NULL;
  }
  p->data = 0;
  p->next = NULL;

  return p;
}

void show(linklist H)
{
  while(H != NULL)
  {
    printf("%d ",H->data);
    H = H->next;
  }
  printf("\n");
}

int main(int argc, char const *argv[]) {

  linklist H = NULL;

  if((H = link_create()) == NULL)
  {
    printf("create link failed\n");
    return -1;
  }

  show(H);

  return 0;
}
