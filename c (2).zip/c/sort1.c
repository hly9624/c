#include <stdio.h>

int main()
{
  int a[8] = {3,1,7,9,4,6,2,5};
  int min,i,j,tmp;

  for(i = 0;i < 8 - 1;i++)
  {
    min = i;
    for(j = i + 1;j < 8;j++)
    {
      if(a[j] < a[min])
      {
        min = j;
      }
    }
    if(i != min)
    {
      tmp = a[i];
      a[i] = a[min];
      a[min] = tmp;
    }
  }


  for(i = 0;i < 8;i++)
    printf("%d ",a[i]);

  printf("\n");

  return 0;
}
