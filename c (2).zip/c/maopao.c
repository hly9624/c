#include <stdio.h>

void maopao(int *a,int n)
{
  int i,j,tmp;

  for(i = 0;i < n - 1;i++)
  {
    for(j = 0;j < n - i - 1;j++)
    {
      if(a[j] > a[j + 1])
      {
        tmp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = tmp;
      }
    }
  }
}

int main(int argc, char const *argv[]) {

  int  a[8] = {3,1,4,2,6,3,5,7};

  maopao(a,8);

  for(int i = 0;i < 8;i++)
  {
    printf("%d ",a[i]);
  }
  printf("\n");
  return 0;
}
