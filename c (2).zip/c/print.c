#include <stdio.h>

int main(int argc, const char *argv[])
{
    int a = 1;
    char b = 'A';
    float c = 1.23;

    printf("字符串\n");

    printf("a = \"%05d\",b = %c\n",a,b);

    printf("c = %6.2f\n",c);

    printf("%#x\n",a);

    printf("%ld\n",sizeof(int));


    return 0;
}
