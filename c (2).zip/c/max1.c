#include <stdio.h>

int main()
{
  int a[3][4] = {3,1,8,9,3,2,4,6,10,6,9,7};
  int max = a[0][0];
  int x,y;
  x = y = 0;

  for (int i = 0; i < 3; i++) {
    for(int j = 0;j < 4;j++)
    if(max < a[i][j])
    {
      max = a[i][j];
      x = i;
      y = j;
    }
  }

  printf("max is a[%d][%d] = %d\n",x,y,max);

  return 0;
}
