#include <stdio.h>

int main(int argc, char const *argv[]) {
  char *a[5] = {"hello","hi","aihao","sawadika","how are you"};

  for(int i = 0;i < 5;i++)
  {
    printf("%s\n",a[i]);
  }

  printf("%c\n",a[2][0]);


  return 0;
}
