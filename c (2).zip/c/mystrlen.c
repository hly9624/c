#include <stdio.h>

size_t mystrlen(const char *s)
{
  int n = 0;

  while(*s++)
  {
    n++;
  }
  return n;
}

int strcmp(const char *s1, const char *s2)
{
  while((*s1 != '\0')  && (*s2 != '\0'))
  {
    if(*s1 > *s2)
      return 1;
    else if(*s1 < *s2)
      return -1;
    s1++;
    s2++;
  }

  if((*s1 == '\0') && (*s2 == '\0'))
    return 0;

  if((*s1 == '\0') && (*s2 != '\0'))
    return -1;
  if((*s1 != '\0') && (*s2 == '\0'))
    return 1;

}

int main(int argc, char const *argv[]) {
  char str1[] = "world";
  char str2[] = "world";

  printf("%d\n",strcmp(str1,str2));

/*
  int len;
  len = mystrlen(str);

  printf("len = %d\n",len);
*/

  return 0;
}
