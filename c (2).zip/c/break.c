#include <stdio.h>

int main(int argc, char const *argv[]) {
  int a = 0;

  while(a <= 20)
  {
    a++;
    if(a % 2 != 0)
    {
      break;
    }
    printf("%d ",a);
  }


  return 0;
}
