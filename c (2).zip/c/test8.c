#include <stdio.h>

int main()

{
    int a ,i,j;
    for (a = 1;a <= 1000;a++)
    {
        j = 0;
        for (i = 1;i < a;i++)
        {
            if(a % i == 0)
            {
                j =j + i;
            }
        }
            
        if(j == a)
        {   
            printf("%d ",j);
        }
    }
    printf("\n");
    return 0;
}
        
