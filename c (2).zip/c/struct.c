#include <stdio.h>

struct Stu{
  int id;
  char name[64];
  int age;
  float salary;
}c = {3,"wangwu",24,8000};

struct {
  int id;
  char name[64];
  int age;
  float salary;
}f;

struct Stu b,d;

int main(int argc, char const *argv[]) {

  struct Stu  a = {1,"lisi",23,8000.0},e = {2,"zhaoliu",29,15000};

  a.salary = 9000;

  a = c;

  printf("%d\n",a.id);
  printf("%s\n",a.name);
  printf("%d\n",a.age);
  printf("%f\n",a.salary);

  return 0;
}
