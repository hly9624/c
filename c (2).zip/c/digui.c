#include <stdio.h>

int fun(int n);
void main()
{
  printf("%d\n",fun(9));
}

int fun (int n)
{
  int t = 1;
  if(n > 0)
  t = n * fun(n - 1);

  return t;
}
