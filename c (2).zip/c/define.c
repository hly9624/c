#include <stdio.h>

#define ONE 1
#define TWO (1 + 1)
#define THREE (ONE + TWO)

int main(int argc, char const *argv[]) {


  printf("%d\n",ONE);
  printf("%d\n",TWO);
  printf("%d\n",THREE);
  printf("%d\n",TWO * THREE);

  return 0;
}
