#include <stdio.h>
#include <math.h>


int main(int argc, const char *argv[])
{
    int a = 1;
    float b = 2.2;

    int c = 9;

    printf("%f\n",sqrt(c));

    printf("a = %f\n",(float)a);
    printf("b =  %d\n",(int)b);

    printf("%f\n",a + b);

    printf("%.20f\n",1.1 + 1.1);
    
    printf("%d\n",a < b || a == 2);

    printf("%d\n",13 & 9);

    printf("a++ = %d\n",a++);
    printf("++a = %d\n",++a);
    


    return 0;
}
