#include <stdio.h>

int main(int argc, char const *argv[]) {

  int score;
  scanf("%d",&score);


  if(score < 0 || score > 100)
  {
    printf("Sorry,your score error!\n");
    return -1;
  }

  score /= 10;

  switch (score) {
    case 10:
    case 9:
      printf("A\n");
      break;
    case 8:
      printf("B\n");
      break;
    case 7:
      printf("C\n");
      break;
    case 6:
      printf("D\n");
      break;
    default:
      printf("sorry!");
  }
  return 0;
}
