#include <stdio.h>

int main()
{
  int i;
  int a[6] = {4,1,2,6,7,3};
  int *p = a;


  for(i = 0;i < 6;i++)
  {
    printf("%d ",a[i]);
  }
  printf("\n+++++++++++++++++++++++++++++++\n");
  for(i = 0;i < 6;i++)
  {
    printf("%d ",p[i]);
  }
  printf("\n+++++++++++++++++++++++++++++++\n");

  for(i = 0;i < 6;i++)
  {
    printf("%d ",*(p + i));
  }
  printf("\n+++++++++++++++++++++++++++++++\n");

  for(i = 0;i < 6;i++)
  {
    printf("%d ",*p++);
  }
  printf("\n+++++++++++++++++++++++++++++++\n");

  for(i = 0;i < 6;i++)
  {
    printf("%d ",*(a + i));
  }
  printf("\n+++++++++++++++++++++++++++++++\n");

/*a是常量
  for(i = 0;i < 6;i++)
  {
    printf("%d ",*a++);
  }
  printf("\n+++++++++++++++++++++++++++++++\n");
*/


  return 0;
}
