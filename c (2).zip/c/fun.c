#include <stdio.h>

int sum(int ,int );

int main(int argc, char const *argv[]) {

  int r;

  r = sum(1,2);

  printf("r = %d\n",r);

  return 0;
}

int sum(int a,int b)
{
  int c;
  c = a + b;
  return c;
}
