#include <stdio.h>

int main(int argc, const char *argv[])
{
    int a = 130;
    char b = 'A';
    float c = 1.9;

    b = a;

    printf("a = %d\n",a);
    printf("b = %c\n",b);

    a = c;
    printf("a = %d\n",a);



    return 0;
}
