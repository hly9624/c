#include <stdio.h>

int main(int argc, const char *argv[])
{
    int a;
    long b;
    short c = 2,d = 4;
    
    a = 1;
    b = a + c;

    printf("b = %ld\n",b);


    float e = 1.2;
    double f = 1.2e+4;

    printf("%f\n",e);
    printf("%lf\n",f);

    char g = 'a';

    printf("%c\n",g);

    return 0;
}
