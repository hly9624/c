#include <stdio.h>

int main(int argc,char *argv[])
{
  int sum = 0;
  char *p = argv[1];

  if(argc < 2)
  {
    printf("argc error");
  }

  while(*p != '\0')
  {
    if(*p != '0')
    {
      sum = sum * 10 + *p - '0';
    }
    p++;
  }

  printf("sum = %d\n",sum);

  return 0;
}
