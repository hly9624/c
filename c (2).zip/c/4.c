#include <stdio.h>
void *paixu(int x,int *a)
{
  int i,j,tmp;
  for(i = 9 - x;i < 9;i++)
  {
    tmp = a[i];
    for(j = i - 1;j >= 0 && tmp > a[j];j--)
    {
      a[j+1] = a[j];
    }
    a[j+1] = tmp;
  }

  for(i = 1;i < x;i++)
  {
    tmp = a[i];
    for(j = i - 1;j >= 0 && tmp < a[j];j--)
    {
      a[j+1] = a[j];
    }
    a[j+1] = tmp;
  }

}
int main(int argc, char const *argv[]) {
  int a[9]={1,2,3,4,5,6,7,8,9};
  int x,i;
  scanf("%d",&x);
  paixu(x,a);
  for(i = 0;i < 9;i++)
  {
    printf("%d ",a[i]);
  }
  printf("\n");
  return 0;
}
