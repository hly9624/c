#include <stdio.h>
int odd(int *a,int n)
{
  int i,j,tmp;
  for(i = 0;i < 10;i++)
  {
    for(j = 0;j < 10;j++)
    {
      if (a[i] % 2 != 0 && a[j] % 2 == 0)
      {
          tmp = a[i];
          a[i] = a[j];
          a[j] = tmp;
      }
    }
  }
}

int main(int argc, char const *argv[]) {
  int a[10] = {1,2,3,5,7,6,4,8,3,12};
  int i;
  odd(a,10);
  for(i = 0;i < 10;i++){
    printf("%d ",a[i]);
  }
  printf("\n" );
  return 0;
}
