#include <stdio.h>

char *mystrcat(char *dest, const char *src)
{
  char * p = dest;

  while(*p != '\0')
  {
    p++;
  }

  while(*src != '\0')
  {
    *p++ = *src++;
  }

  *p = '\0';

  return dest;
}

int main(int argc, const char *argv[])
{
	char dest[64] = "Hello World";
	char src[32] = "This is a test";

	/* 字符串的拼接函数 ,注意数组的大小*/
	mystrcat(dest, src);

	printf("%s\n", dest);


	return 0;
}
