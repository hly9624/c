#include <stdio.h>

int main(int argc, char const *argv[]) {
  int i = 0,sum = 0;

  do{
    sum += ++i;
  }while(i < 100);

  printf("%d\n",sum );

  return 0;
}
