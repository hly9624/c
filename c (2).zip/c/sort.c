#include <stdio.h>

int main(int argc, char const *argv[]) {
  int a[6] = {3,1,4,2,6,5};
  int i,j,tmp;

  for(i = 0;i < 6 - 1;i++)
  {
    for(j = 0;j < 6 - i - 1;j++)
    {
      if(a[j] > a[j + 1])
      {
        tmp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = tmp;
      }
    }

  }

  for(i = 0;i < 6;i++)
  {
    printf("%d ",a[i]);
  }

  printf("\n");


  return 0;
}
